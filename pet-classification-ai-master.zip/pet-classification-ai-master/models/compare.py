"""
Model Comparison Script
Compare different architectures and visualize results
"""

import torch
import json
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import os
from datetime import datetime

# Set style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (15, 10)


def load_training_history(model_name):
    """Load training history from JSON file"""
    
    history_path = f'../results/{model_name}_history.json'
    
    if not os.path.exists(history_path):
        print(f"⚠️  History not found for {model_name}")
        return None
    
    with open(history_path, 'r') as f:
        history = json.load(f)
    
    return history


def plot_model_comparison(histories, save_path):
    """Plot comparison of multiple models"""
    
    fig, axes = plt.subplots(2, 2, figsize=(18, 12))
    
    colors = ['#667eea', '#f093fb', '#10b981', '#f59e0b']
    
    # Training Loss
    ax = axes[0, 0]
    for i, (name, history) in enumerate(histories.items()):
        if history:
            ax.plot(history['train_loss'], label=name, 
                   linewidth=2.5, color=colors[i % len(colors)])
    ax.set_xlabel('Epoch', fontsize=12, fontweight='bold')
    ax.set_ylabel('Loss', fontsize=12, fontweight='bold')
    ax.set_title('Training Loss Comparison', fontsize=14, fontweight='bold', pad=15)
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    
    # Validation Loss
    ax = axes[0, 1]
    for i, (name, history) in enumerate(histories.items()):
        if history:
            ax.plot(history['val_loss'], label=name, 
                   linewidth=2.5, color=colors[i % len(colors)])
    ax.set_xlabel('Epoch', fontsize=12, fontweight='bold')
    ax.set_ylabel('Loss', fontsize=12, fontweight='bold')
    ax.set_title('Validation Loss Comparison', fontsize=14, fontweight='bold', pad=15)
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    
    # Training Accuracy
    ax = axes[1, 0]
    for i, (name, history) in enumerate(histories.items()):
        if history:
            ax.plot(history['train_acc'], label=name, 
                   linewidth=2.5, color=colors[i % len(colors)])
    ax.set_xlabel('Epoch', fontsize=12, fontweight='bold')
    ax.set_ylabel('Accuracy (%)', fontsize=12, fontweight='bold')
    ax.set_title('Training Accuracy Comparison', fontsize=14, fontweight='bold', pad=15)
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    
    # Validation Accuracy
    ax = axes[1, 1]
    for i, (name, history) in enumerate(histories.items()):
        if history:
            ax.plot(history['val_acc'], label=name, 
                   linewidth=2.5, color=colors[i % len(colors)])
    ax.set_xlabel('Epoch', fontsize=12, fontweight='bold')
    ax.set_ylabel('Accuracy (%)', fontsize=12, fontweight='bold')
    ax.set_title('Validation Accuracy Comparison', fontsize=14, fontweight='bold', pad=15)
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Saved model comparison to {save_path}")


def create_summary_table(histories, save_path):
    """Create summary table of model performance"""
    
    summary_data = []
    
    for name, history in histories.items():
        if history:
            best_val_acc = max(history['val_acc'])
            best_epoch = history['val_acc'].index(best_val_acc) + 1
            final_train_acc = history['train_acc'][-1]
            final_val_acc = history['val_acc'][-1]
            total_epochs = len(history['train_acc'])
            
            summary_data.append({
                'Model': name,
                'Best Val Acc (%)': f"{best_val_acc:.2f}",
                'Best Epoch': best_epoch,
                'Final Train Acc (%)': f"{final_train_acc:.2f}",
                'Final Val Acc (%)': f"{final_val_acc:.2f}",
                'Total Epochs': total_epochs,
                'Overfitting': f"{final_train_acc - final_val_acc:.2f}%"
            })
    
    df = pd.DataFrame(summary_data)
    
    # Save to CSV
    csv_path = save_path.replace('.png', '.csv')
    df.to_csv(csv_path, index=False)
    
    # Create visualization
    fig, ax = plt.subplots(figsize=(14, 6))
    ax.axis('tight')
    ax.axis('off')
    
    table = ax.table(cellText=df.values, colLabels=df.columns,
                    cellLoc='center', loc='center',
                    colWidths=[0.15, 0.15, 0.12, 0.15, 0.15, 0.12, 0.12])
    
    table.auto_set_font_size(False)
    table.set_fontsize(11)
    table.scale(1, 2.5)
    
    # Style header
    for i in range(len(df.columns)):
        cell = table[(0, i)]
        cell.set_facecolor('#667eea')
        cell.set_text_props(weight='bold', color='white')
    
    # Style rows
    for i in range(1, len(df) + 1):
        for j in range(len(df.columns)):
            cell = table[(i, j)]
            if i % 2 == 0:
                cell.set_facecolor('#f8f9fa')
            else:
                cell.set_facecolor('white')
    
    plt.title('Model Performance Summary', fontsize=16, fontweight='bold', pad=20)
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Saved summary table to {save_path}")
    print(f"✓ Saved summary CSV to {csv_path}")
    
    return df


def plot_final_comparison(histories, save_path):
    """Create bar chart of final accuracies"""
    
    models = []
    train_accs = []
    val_accs = []
    
    for name, history in histories.items():
        if history:
            models.append(name)
            train_accs.append(history['train_acc'][-1])
            val_accs.append(history['val_acc'][-1])
    
    x = range(len(models))
    width = 0.35
    
    fig, ax = plt.subplots(figsize=(12, 7))
    
    bars1 = ax.bar([i - width/2 for i in x], train_accs, width, 
                   label='Training Accuracy', color='#667eea', alpha=0.8)
    bars2 = ax.bar([i + width/2 for i in x], val_accs, width, 
                   label='Validation Accuracy', color='#10b981', alpha=0.8)
    
    ax.set_xlabel('Model', fontsize=12, fontweight='bold')
    ax.set_ylabel('Accuracy (%)', fontsize=12, fontweight='bold')
    ax.set_title('Final Model Accuracy Comparison', fontsize=14, fontweight='bold', pad=15)
    ax.set_xticks(x)
    ax.set_xticklabels(models, fontsize=11)
    ax.legend(fontsize=11)
    ax.grid(axis='y', alpha=0.3)
    
    # Add value labels on bars
    for bars in [bars1, bars2]:
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{height:.1f}%', ha='center', va='bottom', fontsize=10, fontweight='bold')
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Saved final comparison to {save_path}")


def main():
    """Main comparison function"""
    
    print("\n" + "="*60)
    print("📊 Model Comparison Analysis")
    print("="*60 + "\n")
    
    # Create results directory
    os.makedirs('../results', exist_ok=True)
    
    # Models to compare
    model_names = ['resnet50', 'custom']
    
    # Load histories
    print("📂 Loading training histories...\n")
    histories = {}
    for name in model_names:
        history = load_training_history(name)
        if history:
            histories[name.upper()] = history
            print(f"✓ Loaded {name}")
    
    if not histories:
        print("\n❌ No training histories found!")
        print("Please train models first using advanced_pet_classifier.py")
        return
    
    print(f"\n{'='*60}")
    print("Creating Visualizations...")
    print(f"{'='*60}\n")
    
    # Create comparisons
    comparison_path = '../results/model_comparison.png'
    plot_model_comparison(histories, comparison_path)
    
    summary_path = '../results/model_summary.png'
    df = create_summary_table(histories, summary_path)
    
    final_path = '../results/final_accuracy_comparison.png'
    plot_final_comparison(histories, final_path)
    
    # Print summary
    print(f"\n{'='*60}")
    print("Summary Statistics:")
    print(f"{'='*60}\n")
    print(df.to_string(index=False))
    
    print(f"\n{'='*60}")
    print("✅ Comparison Complete!")
    print(f"{'='*60}")
    print(f"Results saved to: ../results/")
    print(f"{'='*60}\n")


if __name__ == '__main__':
    main()
