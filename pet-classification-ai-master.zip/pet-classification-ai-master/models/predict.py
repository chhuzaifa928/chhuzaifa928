"""
Simple Inference Script
Quick testing of trained model on single images
"""

import torch
import torch.nn as nn
from torchvision import transforms
from PIL import Image
import sys
import os
import pandas as pd

# Add parent directory to path
sys.path.append(os.path.dirname(__file__))
from train import get_model


def load_model(model_path, model_name='resnet50', num_classes=74):
    """Load trained model"""
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = get_model(model_name, num_classes=num_classes, pretrained=False)
    
    checkpoint = torch.load(model_path, map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    model = model.to(device)
    model.eval()
    
    return model, device


def predict_image(image_path, model, device, class_names, top_k=5):
    """Predict single image"""
    
    # Load and transform image
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                           std=[0.229, 0.224, 0.225])
    ])
    
    try:
        image = Image.open(image_path).convert('RGB')
    except Exception as e:
        print(f"❌ Error loading image: {e}")
        return None
    
    img_tensor = transform(image).unsqueeze(0).to(device)
    
    # Make prediction
    with torch.no_grad():
        outputs = model(img_tensor)
        probabilities = torch.softmax(outputs, dim=1)[0]
        
        # Get top k predictions
        top_probs, top_indices = torch.topk(probabilities, top_k)
        
        predictions = []
        for prob, idx in zip(top_probs, top_indices):
            predictions.append({
                'class': class_names[idx.item()],
                'probability': prob.item(),
                'percentage': prob.item() * 100
            })
    
    return predictions


def main():
    """Main inference function"""
    
    # Configuration
    model_name = 'resnet50'
    model_path = f'../saved_models/{model_name}_best.pth'
    
    # Check arguments
    if len(sys.argv) < 2:
        print("\n" + "="*60)
        print("🔍 Pet Classification - Quick Inference")
        print("="*60)
        print("\nUsage: python inference.py <image_path>")
        print("\nExample:")
        print("  python inference.py ../Choose\\ pet\\ datset\\ for\\ kaggle/Beagle/1.jpg")
        print("="*60 + "\n")
        return
    
    image_path = sys.argv[1]
    
    # Check if image exists
    if not os.path.exists(image_path):
        print(f"❌ Image not found: {image_path}")
        return
    
    # Check if model exists
    if not os.path.exists(model_path):
        print(f"❌ Model not found: {model_path}")
        print("Please train the model first using advanced_pet_classifier.py")
        return
    
    print("\n" + "="*60)
    print("🔍 Pet Classification - Quick Inference")
    print("="*60 + "\n")
    
    # Load class names
    try:
        data = pd.read_csv('../test_dataset.csv')
        class_names = sorted(data.iloc[:, 0].apply(lambda x: x.split('/')[0]).unique())
    except:
        class_names = [f"Class_{i}" for i in range(74)]
    
    # Load model
    print("📦 Loading model...")
    model, device = load_model(model_path, model_name=model_name)
    print(f"✓ Model loaded: {model_name}")
    print(f"✓ Device: {device}\n")
    
    # Make prediction
    print(f"🖼️  Analyzing image: {os.path.basename(image_path)}")
    print("-" * 60)
    
    predictions = predict_image(image_path, model, device, class_names, top_k=5)
    
    if predictions:
        print("\n📊 Predictions:\n")
        
        # Top prediction
        top = predictions[0]
        print(f"🏆 Top Prediction: {top['class']}")
        print(f"   Confidence: {top['percentage']:.2f}%\n")
        
        # All predictions
        print("All Top-5 Predictions:")
        print("-" * 60)
        for i, pred in enumerate(predictions, 1):
            bar_length = int(pred['percentage'] / 2)
            bar = '█' * bar_length + '░' * (50 - bar_length)
            print(f"{i}. {pred['class']:<25} {bar} {pred['percentage']:6.2f}%")
        
        print("\n" + "="*60 + "\n")


if __name__ == '__main__':
    main()
