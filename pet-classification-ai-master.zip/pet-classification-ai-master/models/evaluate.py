"""
Comprehensive Model Evaluation Script
Features:
- Confusion matrix visualization
- Per-class accuracy analysis
- Classification report
- Top-k accuracy
- Error analysis
"""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import transforms
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from tqdm import tqdm
import os
import sys

# Import from training script
sys.path.append(os.path.dirname(__file__))
from train import PetDataset, get_model

# Set style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (15, 12)


def load_model(model_path, model_name='resnet50', num_classes=74):
    """Load trained model"""
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = get_model(model_name, num_classes=num_classes, pretrained=False)
    
    checkpoint = torch.load(model_path, map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    model = model.to(device)
    model.eval()
    
    return model, device


def get_predictions(model, dataloader, device):
    """Get all predictions and true labels"""
    
    all_preds = []
    all_labels = []
    all_probs = []
    
    with torch.no_grad():
        for images, labels in tqdm(dataloader, desc='Evaluating'):
            images = images.to(device)
            outputs = model(images)
            probs = torch.softmax(outputs, dim=1)
            _, predicted = outputs.max(1)
            
            all_preds.extend(predicted.cpu().numpy())
            all_labels.extend(labels.numpy())
            all_probs.extend(probs.cpu().numpy())
    
    return np.array(all_preds), np.array(all_labels), np.array(all_probs)


def plot_confusion_matrix(y_true, y_pred, class_names, save_path):
    """Plot confusion matrix"""
    
    cm = confusion_matrix(y_true, y_pred)
    
    # Normalize
    cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    
    # Plot
    plt.figure(figsize=(20, 18))
    sns.heatmap(cm_normalized, annot=False, fmt='.2f', cmap='Blues', 
                xticklabels=class_names, yticklabels=class_names,
                cbar_kws={'label': 'Normalized Count'})
    plt.title('Confusion Matrix (Normalized)', fontsize=16, fontweight='bold', pad=20)
    plt.ylabel('True Label', fontsize=14)
    plt.xlabel('Predicted Label', fontsize=14)
    plt.xticks(rotation=90, ha='right', fontsize=8)
    plt.yticks(rotation=0, fontsize=8)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Saved confusion matrix to {save_path}")


def plot_per_class_accuracy(y_true, y_pred, class_names, save_path):
    """Plot per-class accuracy"""
    
    # Calculate per-class accuracy
    accuracies = []
    for i in range(len(class_names)):
        mask = y_true == i
        if mask.sum() > 0:
            acc = (y_pred[mask] == y_true[mask]).mean() * 100
            accuracies.append(acc)
        else:
            accuracies.append(0)
    
    # Sort by accuracy
    sorted_indices = np.argsort(accuracies)
    sorted_classes = [class_names[i] for i in sorted_indices]
    sorted_accuracies = [accuracies[i] for i in sorted_indices]
    
    # Plot
    fig, ax = plt.subplots(figsize=(12, 20))
    colors = ['#d62728' if acc < 50 else '#ff7f0e' if acc < 75 else '#2ca02c' 
              for acc in sorted_accuracies]
    
    bars = ax.barh(range(len(sorted_classes)), sorted_accuracies, color=colors, alpha=0.8)
    ax.set_yticks(range(len(sorted_classes)))
    ax.set_yticklabels(sorted_classes, fontsize=9)
    ax.set_xlabel('Accuracy (%)', fontsize=12)
    ax.set_title('Per-Class Accuracy', fontsize=14, fontweight='bold', pad=20)
    ax.grid(axis='x', alpha=0.3)
    
    # Add value labels
    for i, (bar, acc) in enumerate(zip(bars, sorted_accuracies)):
        ax.text(acc + 1, i, f'{acc:.1f}%', va='center', fontsize=8)
    
    # Add legend
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor='#2ca02c', alpha=0.8, label='Good (≥75%)'),
        Patch(facecolor='#ff7f0e', alpha=0.8, label='Medium (50-75%)'),
        Patch(facecolor='#d62728', alpha=0.8, label='Poor (<50%)')
    ]
    ax.legend(handles=legend_elements, loc='lower right', fontsize=10)
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"✓ Saved per-class accuracy to {save_path}")
    
    return accuracies


def calculate_topk_accuracy(y_true, probs, k=5):
    """Calculate top-k accuracy"""
    
    top_k_preds = np.argsort(probs, axis=1)[:, -k:]
    correct = 0
    
    for i, true_label in enumerate(y_true):
        if true_label in top_k_preds[i]:
            correct += 1
    
    return 100. * correct / len(y_true)


def analyze_errors(y_true, y_pred, probs, class_names, save_path, top_n=20):
    """Analyze most common errors"""
    
    # Find misclassified samples
    errors = y_true != y_pred
    error_indices = np.where(errors)[0]
    
    # Get confidence of wrong predictions
    confidences = []
    for idx in error_indices:
        conf = probs[idx, y_pred[idx]]
        confidences.append(conf)
    
    # Sort by confidence (most confident errors)
    sorted_indices = np.argsort(confidences)[::-1][:top_n]
    
    # Create error analysis
    error_data = []
    for idx in sorted_indices:
        orig_idx = error_indices[idx]
        error_data.append({
            'True Class': class_names[y_true[orig_idx]],
            'Predicted Class': class_names[y_pred[orig_idx]],
            'Confidence': f"{confidences[idx]*100:.2f}%"
        })
    
    # Save to CSV
    df = pd.DataFrame(error_data)
    csv_path = save_path.replace('.png', '.csv')
    df.to_csv(csv_path, index=False)
    
    # Plot most common error pairs
    error_pairs = {}
    for i in error_indices:
        pair = (class_names[y_true[i]], class_names[y_pred[i]])
        error_pairs[pair] = error_pairs.get(pair, 0) + 1
    
    # Get top error pairs
    top_errors = sorted(error_pairs.items(), key=lambda x: x[1], reverse=True)[:15]
    
    if top_errors:
        fig, ax = plt.subplots(figsize=(12, 8))
        pairs = [f"{true} → {pred}" for (true, pred), _ in top_errors]
        counts = [count for _, count in top_errors]
        
        bars = ax.barh(range(len(pairs)), counts, color='#e74c3c', alpha=0.8)
        ax.set_yticks(range(len(pairs)))
        ax.set_yticklabels(pairs, fontsize=10)
        ax.set_xlabel('Number of Errors', fontsize=12)
        ax.set_title('Most Common Misclassification Pairs', fontsize=14, fontweight='bold', pad=20)
        ax.grid(axis='x', alpha=0.3)
        
        # Add value labels
        for i, (bar, count) in enumerate(zip(bars, counts)):
            ax.text(count + 0.5, i, str(count), va='center', fontsize=10)
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"✓ Saved error analysis to {save_path}")
        print(f"✓ Saved detailed errors to {csv_path}")


def create_evaluation_report(y_true, y_pred, probs, class_names, model_name, save_dir):
    """Create comprehensive evaluation report"""
    
    print(f"\n{'='*60}")
    print(f"📊 Model Evaluation Report: {model_name}")
    print(f"{'='*60}\n")
    
    # Overall accuracy
    overall_acc = accuracy_score(y_true, y_pred) * 100
    print(f"Overall Accuracy: {overall_acc:.2f}%")
    
    # Top-k accuracy
    top3_acc = calculate_topk_accuracy(y_true, probs, k=3)
    top5_acc = calculate_topk_accuracy(y_true, probs, k=5)
    print(f"Top-3 Accuracy: {top3_acc:.2f}%")
    print(f"Top-5 Accuracy: {top5_acc:.2f}%")
    
    # Classification report
    print("\n" + "="*60)
    print("Classification Report (Top 10 Classes):")
    print("="*60)
    report = classification_report(y_true, y_pred, target_names=class_names, 
                                   output_dict=True, zero_division=0)
    
    # Save full report
    report_df = pd.DataFrame(report).transpose()
    report_path = os.path.join(save_dir, f'{model_name}_classification_report.csv')
    report_df.to_csv(report_path)
    print(f"✓ Full classification report saved to {report_path}")
    
    # Print summary
    print(f"\nMacro Avg - Precision: {report['macro avg']['precision']:.3f}, "
          f"Recall: {report['macro avg']['recall']:.3f}, "
          f"F1-Score: {report['macro avg']['f1-score']:.3f}")
    print(f"Weighted Avg - Precision: {report['weighted avg']['precision']:.3f}, "
          f"Recall: {report['weighted avg']['recall']:.3f}, "
          f"F1-Score: {report['weighted avg']['f1-score']:.3f}")
    
    # Visualizations
    print(f"\n{'='*60}")
    print("Creating Visualizations...")
    print(f"{'='*60}\n")
    
    # Confusion matrix
    cm_path = os.path.join(save_dir, f'{model_name}_confusion_matrix.png')
    plot_confusion_matrix(y_true, y_pred, class_names, cm_path)
    
    # Per-class accuracy
    acc_path = os.path.join(save_dir, f'{model_name}_per_class_accuracy.png')
    accuracies = plot_per_class_accuracy(y_true, y_pred, class_names, acc_path)
    
    # Error analysis
    error_path = os.path.join(save_dir, f'{model_name}_error_analysis.png')
    analyze_errors(y_true, y_pred, probs, class_names, error_path)
    
    # Summary statistics
    print(f"\n{'='*60}")
    print("Summary Statistics:")
    print(f"{'='*60}")
    print(f"Best performing class: {class_names[np.argmax(accuracies)]} ({max(accuracies):.2f}%)")
    print(f"Worst performing class: {class_names[np.argmin(accuracies)]} ({min(accuracies):.2f}%)")
    print(f"Average per-class accuracy: {np.mean(accuracies):.2f}%")
    print(f"{'='*60}\n")


def main():
    """Main evaluation function"""
    
    # Configuration
    model_name = 'resnet50'  # or 'custom'
    model_path = f'saved_models/{model_name}_best.pth'
    results_dir = 'results'
    
    os.makedirs(results_dir, exist_ok=True)
    
    # Check if model exists
    if not os.path.exists(model_path):
        print(f"❌ Model not found: {model_path}")
        print("Please train the model first using advanced_pet_classifier.py")
        return
    
    print(f"\n{'='*60}")
    print(f"🔍 Evaluating Model: {model_name}")
    print(f"{'='*60}\n")
    
    # Load model
    print("📦 Loading model...")
    model, device = load_model(model_path, model_name=model_name)
    print(f"✓ Model loaded from {model_path}")
    print(f"✓ Using device: {device}\n")
    
    # Load test data
    print("📂 Loading test dataset...")
    test_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                           std=[0.229, 0.224, 0.225])
    ])
    
    test_dataset = PetDataset(
        csv_file='test_dataset.csv',
        root_dir='Choose pet datset for kaggle',
        transform=test_transform
    )
    
    test_loader = DataLoader(
        test_dataset, 
        batch_size=32, 
        shuffle=False, 
        num_workers=4
    )
    
    print(f"✓ Test samples: {len(test_dataset)}\n")
    
    # Get class names
    data = pd.read_csv('test_dataset.csv')
    class_names = sorted(data.iloc[:, 0].apply(lambda x: x.split('/')[0]).unique())
    print(f"✓ Number of classes: {len(class_names)}\n")
    
    # Get predictions
    print("🎯 Getting predictions...")
    y_pred, y_true, probs = get_predictions(model, test_loader, device)
    print("✓ Predictions complete\n")
    
    # Create evaluation report
    create_evaluation_report(y_true, y_pred, probs, class_names, model_name, results_dir)
    
    print(f"\n{'='*60}")
    print("✅ Evaluation Complete!")
    print(f"{'='*60}")
    print(f"Results saved to: {results_dir}/")
    print(f"{'='*60}\n")


if __name__ == '__main__':
    main()
