/**
 * Pet Classification AI - Frontend Logic
 * Handles image upload, prediction, and UI updates
 */

// DOM Elements
const uploadArea = document.getElementById('uploadArea');
const fileInput = document.getElementById('fileInput');
const browseBtn = document.getElementById('browseBtn');
const previewSection = document.getElementById('previewSection');
const previewImage = document.getElementById('previewImage');
const clearBtn = document.getElementById('clearBtn');
const analyzeBtn = document.getElementById('analyzeBtn');
const loadingSection = document.getElementById('loadingSection');
const resultsSection = document.getElementById('resultsSection');
const topPrediction = document.getElementById('topPrediction');
const predictionsList = document.getElementById('predictionsList');
const tryAgainBtn = document.getElementById('tryAgainBtn');

// State
let selectedFile = null;

// Event Listeners
browseBtn.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', handleFileSelect);
uploadArea.addEventListener('click', () => fileInput.click());
uploadArea.addEventListener('dragover', handleDragOver);
uploadArea.addEventListener('dragleave', handleDragLeave);
uploadArea.addEventListener('drop', handleDrop);
clearBtn.addEventListener('click', resetUpload);
analyzeBtn.addEventListener('click', analyzeImage);
tryAgainBtn.addEventListener('click', resetUpload);

/**
 * Handle file selection
 */
function handleFileSelect(event) {
    const file = event.target.files[0];
    if (file && file.type.startsWith('image/')) {
        selectedFile = file;
        displayPreview(file);
    } else {
        showError('Please select a valid image file');
    }
}

/**
 * Handle drag over
 */
function handleDragOver(event) {
    event.preventDefault();
    uploadArea.classList.add('dragover');
}

/**
 * Handle drag leave
 */
function handleDragLeave(event) {
    event.preventDefault();
    uploadArea.classList.remove('dragover');
}

/**
 * Handle file drop
 */
function handleDrop(event) {
    event.preventDefault();
    uploadArea.classList.remove('dragover');

    const file = event.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
        selectedFile = file;
        fileInput.files = event.dataTransfer.files;
        displayPreview(file);
    } else {
        showError('Please drop a valid image file');
    }
}

/**
 * Display image preview
 */
function displayPreview(file) {
    const reader = new FileReader();

    reader.onload = (e) => {
        previewImage.src = e.target.result;
        previewSection.style.display = 'block';
        resultsSection.style.display = 'none';

        // Smooth scroll to preview
        setTimeout(() => {
            previewSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 100);
    };

    reader.readAsDataURL(file);
}

/**
 * Reset upload
 */
function resetUpload() {
    selectedFile = null;
    fileInput.value = '';
    previewImage.src = '';
    previewSection.style.display = 'none';
    loadingSection.style.display = 'none';
    resultsSection.style.display = 'none';

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

/**
 * Analyze image
 */
async function analyzeImage() {
    if (!selectedFile) {
        showError('Please select an image first');
        return;
    }

    // Show loading
    previewSection.style.display = 'none';
    loadingSection.style.display = 'block';
    resultsSection.style.display = 'none';

    // Scroll to loading
    setTimeout(() => {
        loadingSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);

    // Prepare form data
    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
        // Send request
        const response = await fetch('/predict', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error('Prediction failed');
        }

        const data = await response.json();

        if (data.success) {
            displayResults(data.predictions);
        } else {
            throw new Error(data.error || 'Unknown error');
        }

    } catch (error) {
        console.error('Error:', error);
        showError('Failed to analyze image. Please try again.');
        loadingSection.style.display = 'none';
        previewSection.style.display = 'block';
    }
}

/**
 * Display results
 */
function displayResults(predictions) {
    // Hide loading
    loadingSection.style.display = 'none';

    // Show results
    resultsSection.style.display = 'block';

    // Display top prediction
    const top = predictions[0];
    topPrediction.innerHTML = `
        <div class="prediction-label">Top Prediction</div>
        <div class="prediction-class">${formatClassName(top.class)}</div>
        <div class="prediction-confidence">${top.percentage}%</div>
    `;

    // Display other predictions
    predictionsList.innerHTML = '';
    for (let i = 1; i < predictions.length; i++) {
        const pred = predictions[i];
        const item = createPredictionItem(pred, i);
        predictionsList.appendChild(item);
    }

    // Scroll to results
    setTimeout(() => {
        resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);

    // Animate bars
    setTimeout(() => {
        document.querySelectorAll('.prediction-bar-fill').forEach((bar, index) => {
            setTimeout(() => {
                bar.style.width = bar.dataset.width;
            }, index * 100);
        });
    }, 300);
}

/**
 * Create prediction item
 */
function createPredictionItem(prediction, index) {
    const item = document.createElement('div');
    item.className = 'prediction-item';
    item.style.animationDelay = `${index * 0.1}s`;

    const probability = parseFloat(prediction.percentage);

    item.innerHTML = `
        <span class="prediction-name">${formatClassName(prediction.class)}</span>
        <div class="prediction-bar">
            <div class="prediction-bar-fill" data-width="${probability}%" style="width: 0%"></div>
        </div>
        <span class="prediction-percentage">${prediction.percentage}%</span>
    `;

    return item;
}

/**
 * Format class name
 */
function formatClassName(className) {
    // Remove underscores and capitalize
    return className
        .replace(/_/g, ' ')
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
        .join(' ');
}

/**
 * Show error message
 */
function showError(message) {
    // Create error notification
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 0.5rem;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3);
        z-index: 1000;
        animation: slideInRight 0.3s ease-out;
        font-weight: 600;
    `;
    notification.textContent = message;

    document.body.appendChild(notification);

    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Initialize
console.log('🐾 Pet Classification AI - Ready!');
console.log('Upload an image to get started');
