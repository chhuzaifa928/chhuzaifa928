"""
Flask Web Application for Pet Classification
Real-time image classification with beautiful UI
"""

from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import torch
import torch.nn as nn
from torchvision import transforms
from PIL import Image
import io
import base64
import os
import sys
import json

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from models.train import get_model

app = Flask(__name__)
CORS(app)

# Global variables
model = None
device = None
transform = None
class_names = None


def load_model_and_classes():
    """Load trained model and class names"""
    global model, device, transform, class_names
    
    # Set device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Load model
    model_name = 'resnet50'
    model_path = os.path.join('..', 'saved_models', f'{model_name}_best.pth')
    
    if not os.path.exists(model_path):
        print(f"Warning: Model not found at {model_path}")
        print("Using random initialization for demo purposes")
        model = get_model(model_name, num_classes=74, pretrained=True)
    else:
        model = get_model(model_name, num_classes=74, pretrained=False)
        checkpoint = torch.load(model_path, map_location=device)
        model.load_state_dict(checkpoint['model_state_dict'])
    
    model = model.to(device)
    model.eval()
    
    # Define transform
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                           std=[0.229, 0.224, 0.225])
    ])
    
    # Load class names
    import pandas as pd
    try:
        data = pd.read_csv(os.path.join('..', 'test_dataset.csv'))
        class_names = sorted(data.iloc[:, 0].apply(lambda x: x.split('/')[0]).unique())
    except:
        # Fallback class names
        class_names = [f"Class_{i}" for i in range(74)]
    
    print(f"Model loaded successfully")
    print(f"Device: {device}")
    print(f"Classes: {len(class_names)}")


@app.route('/')
def index():
    """Render main page"""
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    """Handle prediction request"""
    
    try:
        # Get image from request
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Read and process image
        img_bytes = file.read()
        image = Image.open(io.BytesIO(img_bytes)).convert('RGB')
        
        # Transform image
        img_tensor = transform(image).unsqueeze(0).to(device)
        
        # Make prediction
        with torch.no_grad():
            outputs = model(img_tensor)
            probabilities = torch.softmax(outputs, dim=1)[0]
            
            # Get top 5 predictions
            top5_prob, top5_idx = torch.topk(probabilities, 5)
            
            predictions = []
            for prob, idx in zip(top5_prob, top5_idx):
                predictions.append({
                    'class': class_names[idx.item()],
                    'probability': float(prob.item()),
                    'percentage': f"{float(prob.item()) * 100:.2f}"
                })
        
        return jsonify({
            'success': True,
            'predictions': predictions
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/classes')
def get_classes():
    """Get all class names"""
    return jsonify({
        'classes': class_names,
        'count': len(class_names)
    })


if __name__ == '__main__':
    print("\n" + "="*60)
    print("Starting Pet Classification Web App")
    print("="*60 + "\n")
    
    load_model_and_classes()
    
    print("\n" + "="*60)
    print("Server Ready!")
    print("="*60)
    print("Open your browser to: http://localhost:5000")
    print("="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
